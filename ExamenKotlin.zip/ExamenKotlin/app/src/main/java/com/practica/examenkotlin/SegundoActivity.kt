package com.practica.examenkotlin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SegundoActivity : AppCompatActivity() {
    var resultado: TextView? = null
    var Titulo: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segundo)
        var mainActivity = MainActivity()
        var textView = findViewById<View>(R.id.titulo) as TextView
        var textView2 = findViewById<View>(R.id.resultado) as TextView

        /*textView.text = mainActivity.mostrar
        textView2.text = mainActivity.titulo
        println(mainActivity.mostrar)*/
        var obj1=MainActivity.titulo
        var obj2=MainActivity.mostrar
        textView.text = obj1
        textView2.text = obj2
        //println(obj);

    }
    fun regresar(view: View?) {
        println()
        val regresar = Intent(this, MainActivity::class.java)
        startActivity(regresar)
    }
}