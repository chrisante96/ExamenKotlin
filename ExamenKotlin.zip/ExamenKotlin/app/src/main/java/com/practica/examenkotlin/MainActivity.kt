package com.practica .examenkotlin

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import android.widget.CheckBox
import android.widget.AdapterView.OnItemSelectedListener
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var resultado: TextView? = null
    var comboseries: Spinner? = null
    var mensaje: String? = null
    var txt_limite: EditText? = null
    var aceptar: Button? = null
    var Cclaro: CheckBox?=null
    var Coscuro: CheckBox?=null
    var act = 1
    var ant = 0
    //var mostrar: String = ""
    //var titulo : String = ""
    companion object{
        var mostrar: String = ""
        var titulo : String = ""
    }
    var limite = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txt_limite=findViewById(R.id.txt_limite)
        resultado = findViewById<TextView>(R.id.resultado)
        comboseries = findViewById<View>(R.id.seleccion) as Spinner
        Cclaro=findViewById(R.id.checkClaro)
        Coscuro=findViewById(R.id.checkNoche)
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.combo_series,
            android.R.layout.simple_spinner_item
        )
        comboseries!!.adapter = adapter
        comboseries!!.onItemSelectedListener = object : OnItemSelectedListener {
            override fun onItemSelected(
                adapterView: AdapterView<*>,
                view: View,
                i: Int,
                l: Long
            ) {
                mensaje = adapterView.getItemAtPosition(i).toString()
            }

            override fun onNothingSelected(adapterView: AdapterView<*>?) {}
        }
        act = 1
        ant = 0
        mostrar = ""

    }
    fun onCheckboxClicked(view: View){
        var Fondo=findViewById<View>(R.id.fondo) as ConstraintLayout
        //Cclaro?.isChecked ?:true
        Coscuro?.isChecked=false
        if(Cclaro?.isChecked==true){

            Fondo.setBackgroundColor(Color.parseColor("#FFFFFF"))
            comboseries?.setBackgroundColor(Color.parseColor("#FFFFFF"))
            Coscuro?.setTextColor(Color.parseColor("#000000"))
            Cclaro?.setTextColor(Color.parseColor("#000000"))
            textView?.setTextColor(Color.parseColor("#000000"))
            txt_limite?.setTextColor(Color.parseColor("#000000"))
            txt_limite?.setHintTextColor(Color.parseColor("#000000"))
            Cclaro?.setHintTextColor(Color.parseColor("#FFFFFF"))
        }
        else{
            if(Cclaro?.isChecked==false){
                Fondo.setBackgroundColor(Color.parseColor("#673AB7"))
            }
            else{
                //Fondo.setBackgroundColor(Color.parseColor("#CCFFFF"))
            }

        }

    }
    fun onCheckboxClicked2(view: View){
        var Fondo=findViewById<View>(R.id.fondo) as ConstraintLayout
        //Cclaro?.isChecked ?:true
        Cclaro?.isChecked=false
        if(Coscuro?.isChecked==true){
            Fondo.setBackgroundColor(Color.parseColor("#000000"))
            comboseries?.setBackgroundColor(Color.parseColor("#999999"))
            Coscuro?.setTextColor(Color.parseColor("#CCCCCC"))
            Cclaro?.setTextColor(Color.parseColor("#CCCCCC"))
            textView?.setTextColor(Color.parseColor("#999999"))
            txt_limite?.setTextColor(Color.parseColor("#999999"))
            txt_limite?.setHintTextColor(Color.parseColor("#999999"))
            Cclaro?.setHintTextColor(Color.parseColor("#999999"))

        }
        else{
            if(Coscuro?.isChecked==false){
                Fondo.setBackgroundColor(Color.parseColor("#673AB7"))
            }
            else{
                //Fondo.setBackgroundColor(Color.parseColor("#CCFFFF"))
            }

        }
    }
    fun aceptar(view: View?) {

        val siguiente = Intent(this, SegundoActivity::class.java)
        //println(mensaje)
        if (mensaje == "Fibonacci") {
            Fibonacci()
            titulo = "FIBONACCI"

            startActivity(siguiente)
        } else {
            if (mensaje == "Replicas") {
                Replicas()
                titulo = "REPLICAS"
                startActivity(siguiente)
            } else {
                if (mensaje == "Replicas Pares") {
                    ReplicasPares()
                    titulo = "REPLICAS PARES"
                    startActivity(siguiente)
                } else {
                    if (mensaje == "Binario") {
                        Binario()
                        titulo = "BINARIO"
                        startActivity(siguiente)
                    }
                    else{
                        if(mensaje == "Seleccionar..."){
                            Toast.makeText(this, "Selecciones una opcion", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

    }

    fun Fibonacci() {
        txt_limite = findViewById<View>(R.id.txt_limite) as EditText
        limite = txt_limite!!.text.toString().toInt()
        for (i in 0 until limite) {
            val sig = ant + act
            mostrar += "$ant.."
            //println(mostrar)
            ant = act
            act = sig
        }
    }

    fun Replicas() {
        txt_limite = findViewById<View>(R.id.txt_limite) as EditText
        limite = txt_limite!!.text.toString().toInt()
        for (i in 1..limite) {
            for (j in 1..i) {
                mostrar += "$i,"
            }
        }
    }

    fun ReplicasPares() {
        txt_limite = findViewById<View>(R.id.txt_limite) as EditText
        limite = txt_limite!!.text.toString().toInt()
        var i = 2
        while (i <= limite) {
            for (j in 1..i) {
                val num = i
                mostrar += "$num,"
            }
            i = i + 2
        }
    }

    fun Binario() {
        txt_limite = findViewById<View>(R.id.txt_limite) as EditText
        limite = txt_limite!!.text.toString().toInt()
        var num = 0
        for (i in 1..limite) {
            if (i % 2 == 0) {
                for (j in 1..i) {
                    num = 1
                    mostrar += "$num,"
                }
            } else {
                for (j in 1..i) {
                    num = 0
                    mostrar += "$num,"
                }
            }
        }
    }
}